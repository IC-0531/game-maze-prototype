extends Node

signal won
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.

func new_game():
	$Player.start($StartPosition.position)
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

# test2dhfhc

func _on_player_camera() -> void:
	$Camera2D.zoom.x = 4
	$Camera2D.zoom.y = 4


func _on_player_no_camera() -> void:
	$Camera2D.zoom.x = 6
	$Camera2D.zoom.y = 6


func _on_goal_area_shape_entered(area_rid: RID, area: Area2D, area_shape_index: int, local_shape_index: int) -> void:
	print("WIN")
	won.emit()
