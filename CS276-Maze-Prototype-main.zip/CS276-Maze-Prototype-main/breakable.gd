extends StaticBody2D

var nearby = false
@export var player:CharacterBody2D

func _on_area_2d_body_entered(body) -> void:
	if body.is_in_group("player"):
		nearby = true

func _on_area_2d_body_exited(body) -> void:
	if body.is_in_group("player"):
		nearby = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if nearby and Input.is_action_just_pressed("action") and player.tool == "axe":
		queue_free()
