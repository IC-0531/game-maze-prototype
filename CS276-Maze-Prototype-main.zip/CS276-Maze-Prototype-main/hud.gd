extends CanvasLayer

signal start_game
signal hunger_timeout
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Timer.start()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Message.text = str(ceil($Timer.time_left))


func _on_timer_timeout() -> void:
	$Message.text = "Your hunger ran out!"
	hunger_timeout.emit()

func refill():
	$Timer.start()


func _on_food_eat() -> void:
	refill()


func _on_level_0_won() -> void:
	$Timer.paused = true
