extends Area2D
@export var player: CharacterBody2D
signal eat




func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		eat.emit()
		hide()
		# Must be deferred as we can't change physics properties on a physics callback.
		$CollisionShape2D.set_deferred("disabled", true)
