extends CharacterBody2D

signal hit
signal camera
signal noCamera
@onready var axe = $Axe
@onready var weapon = $weapon
@export var tools = ["axe", "binoculars", "weapon"]
@export var current = 0
@export var tool = tools[current]
@export var default_speed = 75
var SPEED = default_speed
@export var DASH_SPEED = 300
@export var health = 3
@export var spawn_position: Marker2D
var can_dash = true
var is_dashing = false
@export_range(0,10000)
var MAX_SPEED:float = 1000
@export_range(0,10000)
var ACCELERATION:float = 1000
@export_range(0,10000)
var DRAG:float = 1000

var screen_size

func _ready():
	screen_size = get_viewport_rect().size
	global_position = spawn_position.global_position
	
func _process(delta: float) -> void:	
	var xdirection := Input.get_axis("left", "right")
	var ydirection := Input.get_axis("up", "down")
	
	if Input.is_action_pressed("dash") and can_dash:
		can_dash = false
		is_dashing = true 
		$DashTime.start()
		$DashCooldown.start()
		
	# Get movement direction
	var direction = Vector2(xdirection, ydirection).normalized()

	# Set target speed
	var target_speed = DASH_SPEED if is_dashing else MAX_SPEED

	if direction != Vector2.ZERO:
		# Gradually accelerate towards target velocity
		velocity = velocity.move_toward(direction * target_speed, ACCELERATION * delta)
	else:
		# Gradually slow down
		velocity = velocity.move_toward(Vector2.ZERO, DRAG * delta)

	if velocity.length() > 0:
		velocity = velocity.normalized() * (DASH_SPEED if is_dashing else SPEED)
		if abs(velocity.x) > abs(velocity.y):
			if velocity.x > 0:
				$AnimatedSprite2D.play("right")
			else:
				$AnimatedSprite2D.play("left")
		else:
			if velocity.y > 0:
				$AnimatedSprite2D.play("down")
			else:
				$AnimatedSprite2D.play("up")
	else:
		$AnimatedSprite2D.stop()

	move_and_slide()
	if tool == "axe":
		axe.visible = Input.is_action_pressed("action")
	if tool == "weapon":
		weapon.visible = Input.is_action_pressed("action")
	if tool == "binoculars" and Input.is_action_pressed("action"):
		SPEED = 25
		$Light.scale.x = 0.5
		$Light.scale.y = 0.5
		camera.emit()
	else:
		SPEED = default_speed
		$Light.scale.x = 0.4
		$Light.scale.y = 0.4
		noCamera.emit()
		
	if Input.is_action_just_pressed("change"):
		change()
		print("changed to: " + tools[current])
		
	
		
func change():
	if current < tools.size()-1:
		current = current + 1
	else:
		current = 0
	tool = tools[current]
	
func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("saw"):
		hit.emit()
		global_position = spawn_position.global_position
		velocity = Vector2.ZERO
		is_dashing = false


func _on_dash_time_timeout() -> void:
	is_dashing = false
	
func _on_player_death():
	hide()
	# Must be deferred as we can't change physics properties on a physics callback.
	$CollisionShape2D.set_deferred("disabled", true)
	health = 0

func _on_dash_cooldown_timeout() -> void:
	can_dash = true


func _on_hud_hunger_timeout() -> void:
	_on_player_death()


func _on_soysauce_soy() -> void:
	SPEED = 100
