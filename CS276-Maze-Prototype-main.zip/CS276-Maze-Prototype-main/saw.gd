extends CharacterBody2D

@export var speed: float = 25
@export var player: CharacterBody2D
var nearby = false
	

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		nearby = true

func _on_area_2d_body_exited(body: Node2D) -> void:
	if body.is_in_group("player"):
		nearby = false
		
func _physics_process(delta: float) -> void:
	if nearby and Input.is_action_just_pressed("action") and player.tool == "weapon":
		queue_free()
		
	$Nav.target_position = player.global_position
	
	velocity = global_position.direction_to(player.global_position) * speed
	move_and_slide()
